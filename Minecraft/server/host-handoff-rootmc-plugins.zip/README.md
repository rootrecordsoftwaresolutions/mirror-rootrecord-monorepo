# RootMC host handoff (zip and upload)

Built plugin jars and config templates for the live Shockbyte Paper server.

**Live server bundle:** `Desktop/RootMC/` (FileZilla sync + local edits). `Desktop/current/` and `Desktop/backup06102026/` are superseded.

**Built:** run from `Minecraft/`:

```powershell
.\build-with-server-jdk.bat :plugins:blocknotes:build :plugins:rootmc-shops:build :plugins:roothelp:build :plugins:root-essentials:build
```

## Zip this folder

From `Minecraft/server/`:

```powershell
Compress-Archive -Path host-handoff\* -DestinationPath host-handoff-rootmc-plugins.zip -Force
```

Upload `host-handoff-rootmc-plugins.zip` via Shockbyte file manager or SFTP.

## On the live host

| Local (in zip) | Live path |
|----------------|-----------|
| `plugins/blocknotes-1.3.4.jar` | `plugins/blocknotes-1.3.4.jar` (remove older `blocknotes-*.jar`) |
| `plugins/rootmc-shops-1.3.3.jar` | `plugins/rootmc-shops-1.3.3.jar` (remove older `rootmc-shops-*.jar`) |
| `plugins/roothelp-1.0.2.jar` | `plugins/roothelp-1.0.2.jar` |
| `plugins/root-essentials-1.4.0.jar` | `plugins/root-essentials-1.4.0.jar` (remove EssentialsX jars during cutover) |
| `config-templates/RootRecord/cloud.yml` | `plugins/RootRecord/cloud.yml` — **set `server-id` + `server-secret` on host** |
| `config-templates/RootRecord/blocknotes.yml` | `plugins/RootRecord/blocknotes.yml` — **set `mysql.password` on host** |
| `config-templates/RootRecord/rootmc-shops.yml` | `plugins/RootRecord/rootmc-shops.yml` |
| `config-templates/RootRecord/root-essentials.yml` | `plugins/RootRecord/root-essentials.yml` — **set `mysql.password` on host** |
| `config-templates/RootRecord/roothelp.yml` | `plugins/RootRecord/roothelp.yml` (optional) |
| `config-templates/luckperms-setup.commands` | Run in console to enforce live LP ranks (`default`, `pro`, `lifetime`, `admin`) |

Disable/remove `EssentialsX` jars before restart, then restart Paper after replacing jars.

## Versions in this bundle

| Plugin | Version | Notes |
|--------|---------|-------|
| BlockNotes | 1.3.4 | `/rootmc link`, economy sync, `/value`, ingame capture, Discord in-game chat bridge |
| RootMC-Shops | 1.3.3 | QuickShop-style chest flow, `/buy` quotes, price cap |
| RootHelp | 1.0.2 | `/rules`, `/cmds`, `/discord`, `/map` |
| Root-Essentials | 1.4.0 | Full EssentialsX replacement — warps, moderation, gold economy |

Auto-update: heartbeat pulls **blocknotes** only from `https://rootrecord.info/realm/plugins/` (manifest). **rootmc-shops** and **roothelp** must be installed manually from this zip (or copy jars from `Web/main/realm/plugins/` after Pages deploy).

## Do not commit secrets

`cloud.yml` on the host must contain your registered `server-id` / `server-secret`. MySQL password lives only on Shockbyte.

## Optional: Towny extras (not in this zip)

Copy separately from `Minecraft/server/config-templates/` if not already on host:

- `Towny/config.yml` + `Towny/worlds/*.txt` (overworld claimable; nether/end not)
- Towny add-ons / optional plugin configs as needed for your host
